﻿
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoo.Model;

namespace Zoo
{
    internal class DbContext : Microsoft.EntityFrameworkCore.DbContext
    {
        public DbContext()
        {

        }
        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            options.UseSqlServer(Properties.Settings.Default.dbConnection);
        }

        public Microsoft.EntityFrameworkCore.DbSet<User> Users { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Animal> Animals { get; set; }

    }
}
