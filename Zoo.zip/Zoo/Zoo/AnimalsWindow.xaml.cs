﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Zoo.ViewModel;

namespace Zoo
{
    public partial class AnimalsWindow : Window
    {
        public AnimalsWindow()
        {
            InitializeComponent();
            DataContext = new AnimalsViewModel();
            this.animalCategories.Items.Add("");
            this.animalCategories.Items.Add("Бозайници");
            this.animalCategories.Items.Add("Птици");
            this.animalCategories.Items.Add("Влечуги");
            this.animalCategories.Items.Add("Риби");
        }
    }
}
