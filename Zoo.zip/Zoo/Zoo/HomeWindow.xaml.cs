﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Zoo
{

    public partial class HomeWindow : Window
    {
        public HomeWindow()
        {
            InitializeComponent();
        }

        private void tickets_MouseEnter(object sender, MouseEventArgs e)
        {
            BitmapImage image = new BitmapImage();
            image.BeginInit();
            image.UriSource = new Uri(@"C:\Users\mtupa\Desktop\Zoo\Zoo\tickets.png");
            image.EndInit();

            this.imageContainer.Source = image;
        }

        private void events_MouseEnter(object sender, MouseEventArgs e)
        {
            BitmapImage image = new BitmapImage();
            image.BeginInit();
            image.UriSource = new Uri(@"C:\Users\mtupa\Desktop\Zoo\Zoo\event-_image.jpg");
            image.EndInit();

            this.imageContainer.Source = image;
        }

        private void animals_MouseEnter(object sender, MouseEventArgs e)
        {
            BitmapImage image = new BitmapImage();
            image.BeginInit();
            image.UriSource = new Uri(@"C:\Users\mtupa\Desktop\Zoo\Zoo\768x432.jpg");
            image.EndInit();

            this.imageContainer.Source = image;
        }

        private void animals_Click(object sender, RoutedEventArgs e)
        {
            Window animalsWindow = new AnimalsWindow();
            animalsWindow.Show();
            this.Close();
        }
    }
}
