﻿using Prism.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Zoo.ViewModel
{
    internal class LoginVIewModel
    {
        private String username;
        private String password;
        private User user;
        private DelegateCommand loginCommand;

        public LoginVIewModel()
        {

        }

        public ICommand LoginCommand
        {
            get
            {
                return loginCommand ?? (loginCommand = new DelegateCommand(() =>
                {
                    if (String.IsNullOrEmpty(this.username))
                    {
                        MessageBox.Show("Моля въведете име!");
                    }
                    else if (String.IsNullOrEmpty(this.password))
                    {
                        MessageBox.Show("Моля въведете парола!");
                    }
                    else
                    {
                        DbContext context = new DbContext();
                        user = context.Users.FirstOrDefault(u => u.username == this.Username && u.password == this.Password);

                        if (user != null)
                        {
                            Window window = new HomeWindow();
                            window.Show();
                            System.Windows.Application.Current.MainWindow.Close();
                        }
                        else
                        {
                            MessageBox.Show("Грешни данни за вход!");
                        }
                    }
                }));
            }
        }

        public String Username
        {
            get
            {
                return username;
            }
            set
            {
                username = value.Trim();
            }
        }

        public String Password
        {
            get
            {
                return password;
            }
            set
            {
                password = value;
            }
        }
    }
}
