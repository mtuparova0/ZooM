﻿using Prism.Commands;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using Zoo.Model;

namespace Zoo.ViewModel
{
    internal class AnimalsViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;
        private List<Animal> animals;
        private DbContext context;
        private string selectedAnimalCategory;
        private Animal selectedAnimal;
        private Animal animal;
        private string animalName;
        private string animalCategory;
        private string animalDescription;
        private string animalImgSrc;
        private ICommand searchCommand;
        private ICommand showAnimalCommand;
        private ICommand backCommand;

        public AnimalsViewModel()
        {
            context = new DbContext();
            animals = context.Animals.ToList();
        }

        public List<Animal> Animals {
            get
            {
                return animals;
            }
            set
            {
                animals = value;
                OnPropertyChanged("Animals");
            }
        }

        public String SelectedAnimalCategory
        {
            get
            {
                return selectedAnimalCategory;
            } 
            set
            {
                selectedAnimalCategory = value;
                OnPropertyChanged("SelectedAnimalCategory");
            }
        }

        public Animal SelectedAnimal
        {
            get
            {
                return selectedAnimal;
            }
            set
            {
                selectedAnimal = value;
                OnPropertyChanged("SelectedAnimal");
            }
        }

        public ICommand SearchCommand
        {
            get
            {
                return searchCommand ?? (searchCommand = new DelegateCommand(() =>
                {
                    if (string.IsNullOrEmpty(selectedAnimalCategory)) {
                        Animals = context.Animals.ToList();
                    } else
                    {
                        List<Animal> animalsByCategory = new List<Animal>();
                        foreach (var animal in animals)
                        {
                            if (animal.category.Equals(selectedAnimalCategory))
                            {
                                animalsByCategory.Add(animal);
                            }
                        }

                        Animals = animalsByCategory;
                    }
                }));
            }
        }

        public ICommand ShowAnimalCommand
        {
            get
            {
                return showAnimalCommand ?? (showAnimalCommand = new DelegateCommand(() =>
                {
                    animal = (from a in animals where a.name.Equals(selectedAnimal.name) select a).FirstOrDefault();
                    if (animal != null)
                    {
                        AnimalName = animal.name;
                        AnimalCategory = animal.category;
                        AnimalDescription = animal.description;
                        AnimalImageSrc = animal.imageSrc;
                    }
                }));
            }
        }

        public ICommand BackCommand
        {
            get
            {
                return backCommand ?? (backCommand = new DelegateCommand(() =>
                {
                    Window window = new HomeWindow();
                    window.Show();
                    System.Windows.Application.Current.MainWindow.Close();
                }));
            }
        }

        public String AnimalName
        {
            get
            {
                if (animal != null)
                {
                    return animalName;
                }
                return "";
            }
            set
            {
                animalName = value;
                OnPropertyChanged("AnimalName");
            }
        } 

        public String AnimalCategory
        {
            get
            {
                if (animal != null)
                {
                    return animalCategory;
                }
                return "";
            }
            set
            {
                animalCategory = animal.category;
                OnPropertyChanged("AnimalCategory");
            }
        }

        public String AnimalDescription
        {
            get
            {
                if (animal != null)
                {
                    return animalDescription;
                }
                return "";
            }
            set
            {
                animalDescription = animal.description;
                OnPropertyChanged("AnimalDescription");
            }
        }

        public String AnimalImageSrc
        {
            get
            {
                if (animal == null)
                {
                    return @"C:\Users\mtupa\Desktop\Zoo\Zoo\default.png";
                } else
                {
                    return animalImgSrc;
                }
            }
            set
            {
                animalImgSrc = animal.imageSrc;
                OnPropertyChanged("AnimalImageSrc");
            }
        }

        private void OnPropertyChanged(String propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
